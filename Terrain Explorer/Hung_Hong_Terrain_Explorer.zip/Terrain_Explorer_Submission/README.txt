Name: Hung Hong

To launch the game:
- Click on Terrain Explorer.ext
- Move around using Up/Down/Left/Right arrow key
- Press ENTER to generate new map
- Press SPACEBAR to switch view

Images for Demo is in the Images folder

Project is coded entirely on GameMaker Studio 1.4